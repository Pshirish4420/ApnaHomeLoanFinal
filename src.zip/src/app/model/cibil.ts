export class Cibil {
    cibilId:number;
    cibil_Score_Date_Time:string;
    cibil_Status:string;
    cibil_Remark:string;
    cibil_Score:number;
}
