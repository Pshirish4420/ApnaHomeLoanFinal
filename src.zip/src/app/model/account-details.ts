export class AccountDetails {
    accountId:number;
    accounntNo:string;
    account_type:string;
    account_holdername:string;
    ifsc_code:string;
}
