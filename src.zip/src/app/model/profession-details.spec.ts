import { ProfessionDetails } from './profession-details';

describe('ProfessionDetails', () => {
  it('should create an instance', () => {
    expect(new ProfessionDetails()).toBeTruthy();
  });
});
