export class Documents {
    documentId:number;
    status:String;
    address_Proof:any[];
    pancard:any[];
    aadharcard:any[];
    signature:any[];
    photo:any[];
    incometax:any[];
    salaryslip:any[];
    bankcheck:any[];
  
}
