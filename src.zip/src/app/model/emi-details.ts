export class EmiDetails {
    emiId:number;
    emiAmtMonnthly:number;
    emiDueDate:string;
    previousEmiStatus:string;
}
