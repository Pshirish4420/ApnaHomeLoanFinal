export class ProfessionDetails {
    proffessionid:number;
    designation:string;
    proffession_name:string;
    proffession_type:string;
    annual_salary:string;
}
