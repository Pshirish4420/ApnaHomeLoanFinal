import { LoanDetails } from './loan-details';

describe('LoanDetails', () => {
  it('should create an instance', () => {
    expect(new LoanDetails()).toBeTruthy();
  });
});
