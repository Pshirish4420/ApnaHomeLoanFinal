export class PropertyDetails {
    propertyID:number;
    property_type:string;
    property_area:string;
    property_price:string;
    property_address:string;
}
