
import { Cibil } from "./cibil";

export class Applicant {
    applicantid:number;
    applicant_name: string;
    applicant_occupation: string;
    applicant_pancard: string;
    applicant_email:string;
    cibil:Cibil;
}
