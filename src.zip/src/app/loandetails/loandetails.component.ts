import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loandetails',
  templateUrl: './loandetails.component.html',
  styleUrls: ['./loandetails.component.css']
})
export class LoandetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
