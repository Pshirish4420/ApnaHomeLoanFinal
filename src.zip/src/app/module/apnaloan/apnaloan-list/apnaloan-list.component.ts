import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-apnaloan-list',
  templateUrl: './apnaloan-list.component.html',
  styleUrls: ['./apnaloan-list.component.css']
})
export class ApnaloanListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
