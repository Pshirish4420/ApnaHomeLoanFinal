import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-application-list',
  templateUrl: './all-application-list.component.html',
  styleUrls: ['./all-application-list.component.css']
})
export class AllApplicationListComponent implements OnInit {
retriveDoc: any;

  constructor() { }

  ngOnInit(): void {
  }

}
