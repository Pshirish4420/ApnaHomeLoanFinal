import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approved-list',
  templateUrl: './approved-list.component.html',
  styleUrls: ['./approved-list.component.css']
})
export class ApprovedListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
